import React, { useMemo, useState } from 'react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  BarChart, Bar, PieChart, Pie, Cell, AreaChart, Area, ReferenceLine, Legend
} from 'recharts';
import { 
  TrendingUp, Users, ShoppingCart, DollarSign, 
  Filter, Download, Upload, Info, AlertCircle,
  Calendar, ChevronDown, HelpCircle, Youtube, Globe, ExternalLink
} from 'lucide-react';
import { motion } from 'motion/react';
import { SalesData, DashboardStats } from '../types';
import { formatCurrency, formatNumber, parseCSV } from '../utils/data-parser';
import { INITIAL_CSV_DATA } from '../constants';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const COLORS = ['#8b5cf6', '#0ea5e9', '#06b6d4', '#10b981', '#ec4899'];

export default function Dashboard() {
  const [csvData, setCsvData] = useState<string>(INITIAL_CSV_DATA);
  const [activeTab, setActiveTab] = useState('Overview');
  const [selectedAgeGroups, setSelectedAgeGroups] = useState<string[]>([]);
  const [revenueGoal, setRevenueGoal] = useState<number>(150000);

  const data = useMemo(() => parseCSV(csvData), [csvData]);

  const ageGroups = useMemo(() => {
    return Array.from(new Set(data.map(d => d.Age_Group)));
  }, [data]);

  const filteredData = useMemo(() => {
    if (selectedAgeGroups.length === 0) return data;
    return data.filter(d => selectedAgeGroups.includes(d.Age_Group));
  }, [data, selectedAgeGroups]);

  const stats = useMemo((): DashboardStats => {
    const totalRevenue = filteredData.reduce((sum, d) => sum + d.Revenue, 0);
    const totalOrders = filteredData.length;
    const totalQuantity = filteredData.reduce((sum, d) => sum + d.Order_Quantity, 0);
    const avgOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;

    return {
      totalRevenue,
      totalOrders,
      totalQuantity,
      avgOrderValue
    };
  }, [filteredData]);

  const trendData = useMemo(() => {
    const sorted = [...filteredData].sort((a, b) => a.parsedDate.getTime() - b.parsedDate.getTime());
    return sorted.map(d => ({
      name: d.Date,
      revenue: d.Revenue,
      quantity: d.Order_Quantity,
      purchases: d.Order_Quantity * 0.8 // Simulated for dual axis
    }));
  }, [filteredData]);

  const stackedData = useMemo(() => {
    const dateMap = new Map<string, any>();
    data.forEach(d => {
      if (!dateMap.has(d.Date)) {
        dateMap.set(d.Date, { name: d.Date });
      }
      const entry = dateMap.get(d.Date);
      entry[d.Age_Group] = (entry[d.Age_Group] || 0) + d.Revenue;
    });
    return Array.from(dateMap.values()).sort((a, b) => {
        const da = new Date(a.name).getTime();
        const db = new Date(b.name).getTime();
        return da - db;
    });
  }, [data]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        setCsvData(text);
      };
      reader.readAsText(file);
    }
  };

  const toggleAgeGroup = (group: string) => {
    setSelectedAgeGroups(prev => 
      prev.includes(group) ? prev.filter(g => g !== group) : [...prev, group]
    );
  };

  return (
    <div className="min-h-screen bg-[#eef2f6] font-sans text-slate-900">
      {/* Top Header/Nav */}
      <header className="bg-[#1e40af] text-white px-6 py-3 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-4">
          <div className="bg-white p-1.5 rounded-lg">
            <div className="w-8 h-8 bg-[#0ea5e9] rounded flex items-center justify-center font-bold text-white">C</div>
          </div>
          <div>
            <h1 className="text-xl font-bold leading-tight">Web analytics dashboard</h1>
            <p className="text-xs text-blue-200 font-medium">COUPLER.IO</p>
          </div>
        </div>

        <nav className="hidden lg:flex items-center gap-1">
          {['Overview', 'Acquisition', 'Geo view', 'Behavior', 'Key events', 'About Coupler'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={cn(
                "px-4 py-2 rounded-md text-sm font-medium transition-colors",
                activeTab === tab ? "bg-[#3b82f6] text-white" : "text-blue-100 hover:bg-blue-700/50"
              )}
            >
              {tab}
            </button>
          ))}
          <button className="ml-4 bg-white text-blue-700 px-4 py-2 rounded-md text-sm font-bold hover:bg-blue-50 transition-colors">
            Setup dashboard
          </button>
        </nav>
      </header>

      <div className="flex flex-col lg:flex-row p-6 gap-6">
        {/* Main Content Area */}
        <div className="flex-1 space-y-6">
          {/* KPI Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            <KPICard 
              title="Total Revenue" 
              value={formatCurrency(stats.totalRevenue)} 
              color="bg-[#6366f1]"
              subValue="81.35K"
              label="Total users"
            />
            <KPICard 
              title="New Orders" 
              value={formatNumber(stats.totalOrders)} 
              color="bg-[#1e40af]"
              subValue="57.04K"
              label="New users"
            />
            <KPICard 
              title="Total Quantity" 
              value={formatNumber(stats.totalQuantity)} 
              color="bg-[#0ea5e9]"
              subValue="100.81K"
              label="Sessions"
            />
            <KPICard 
              title="Purchases" 
              value="1.81K" 
              color="bg-[#10b981]"
              subValue="1.81K"
              label="Purchases"
            />
            <KPICard 
              title="Revenue" 
              value={formatCurrency(stats.totalRevenue / 10)} 
              color="bg-[#ec4899]"
              subValue="12.64K"
              label="Revenue"
            />
          </div>

          {/* Charts Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Recent Daily Traffic */}
            <ChartContainer title="Recent Daily Traffic" className="lg:col-span-1">
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="name" hide />
                  <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10}} />
                  <Tooltip />
                  <Line type="monotone" dataKey="revenue" stroke="#1e40af" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
              <div className="flex justify-between mt-2 text-[10px] text-slate-400 font-medium">
                <span>Apr 06</span>
                <span>Apr 13</span>
                <span>Apr 20</span>
                <span>Apr 27</span>
                <span>May 04</span>
              </div>
            </ChartContainer>

            {/* Recent Daily Purchases & Revenue */}
            <ChartContainer title="Recent Daily Purchases & Revenue" className="lg:col-span-1">
                <div className="flex gap-4 mb-2">
                    <div className="flex items-center gap-1.5">
                        <div className="w-2 h-2 rounded-full bg-[#1e40af]" />
                        <span className="text-[10px] font-bold text-slate-600">Purchases</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                        <div className="w-2 h-2 rounded-full bg-[#0ea5e9]" />
                        <span className="text-[10px] font-bold text-slate-600">Revenue</span>
                    </div>
                </div>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="name" hide />
                  <YAxis yAxisId="left" axisLine={false} tickLine={false} tick={{fontSize: 10}} />
                  <YAxis yAxisId="right" orientation="right" axisLine={false} tickLine={false} tick={{fontSize: 10}} />
                  <Tooltip />
                  <Line yAxisId="left" type="monotone" dataKey="purchases" stroke="#1e40af" strokeWidth={2} dot={false} />
                  <Line yAxisId="right" type="monotone" dataKey="revenue" stroke="#0ea5e9" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
              <div className="flex justify-between mt-2 text-[10px] text-slate-400 font-medium">
                <span>Apr 06</span>
                <span>Apr 20</span>
                <span>May 04</span>
              </div>
            </ChartContainer>

            {/* Weekly Traffic for Last 6 Months */}
            <ChartContainer title="Weekly Traffic for Last 6 Months" className="lg:col-span-1">
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="name" hide />
                  <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10}} />
                  <Tooltip />
                  <Line type="monotone" dataKey="revenue" stroke="#1e40af" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
              <div className="flex justify-between mt-2 text-[10px] text-slate-400 font-medium">
                <span>Jan 2025</span>
                <span>Mar 2025</span>
                <span>May 2025</span>
              </div>
            </ChartContainer>

            {/* Recent Daily Traffic by Channels (Stacked Area) */}
            <ChartContainer title="Recent Daily Traffic by Channels" className="lg:col-span-2">
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={stackedData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="name" hide />
                  <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10}} />
                  <Tooltip />
                  <Legend verticalAlign="top" align="left" iconType="circle" wrapperStyle={{ fontSize: '10px', fontWeight: 'bold', paddingBottom: '20px' }} />
                  {ageGroups.map((group, index) => (
                    <Area 
                        key={group} 
                        type="monotone" 
                        dataKey={group} 
                        stackId="1" 
                        stroke={COLORS[index % COLORS.length]} 
                        fill={COLORS[index % COLORS.length]} 
                        fillOpacity={0.2}
                    />
                  ))}
                </AreaChart>
              </ResponsiveContainer>
              <div className="flex justify-between mt-2 text-[10px] text-slate-400 font-medium">
                <span>Apr 06</span>
                <span>Apr 13</span>
                <span>Apr 20</span>
                <span>Apr 27</span>
                <span>May 04</span>
              </div>
            </ChartContainer>

            {/* Monthly Traffic for Last 12 Months */}
            <ChartContainer title="Monthly Traffic for Last 12 Months" className="lg:col-span-1">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="name" hide />
                  <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10}} />
                  <Tooltip />
                  <Bar dataKey="revenue" fill="#1e40af" radius={[2, 2, 0, 0]} />
                  <ReferenceLine y={revenueGoal} stroke="#ef4444" strokeDasharray="3 3" label={{ position: 'top', value: 'Goal', fill: '#ef4444', fontSize: 10 }} />
                </BarChart>
              </ResponsiveContainer>
              <div className="flex justify-between mt-2 text-[10px] text-slate-400 font-medium">
                <span>Jul 2024</span>
                <span>Jan 2025</span>
              </div>
            </ChartContainer>
          </div>
        </div>

        {/* Right Sidebar Filters */}
        <aside className="w-full lg:w-72 space-y-6">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-2 text-slate-400">
                    <Calendar className="w-4 h-4" />
                    <span className="text-xs font-bold">4/6/2025</span>
                </div>
                <div className="flex items-center gap-2 text-slate-400">
                    <Calendar className="w-4 h-4" />
                    <span className="text-xs font-bold">5/7/2025</span>
                </div>
            </div>
            
            {/* Range Slider Placeholder */}
            <div className="relative h-1 bg-slate-100 rounded-full mb-8">
                <div className="absolute left-1/4 right-1/4 h-full bg-blue-500" />
                <div className="absolute left-1/4 top-1/2 -translate-y-1/2 w-4 h-4 bg-white border-2 border-blue-500 rounded-full shadow-sm cursor-pointer" />
                <div className="absolute right-1/4 top-1/2 -translate-y-1/2 w-4 h-4 bg-white border-2 border-blue-500 rounded-full shadow-sm cursor-pointer" />
            </div>

            <div className="space-y-6">
                <div>
                    <label className="block text-xs font-bold text-slate-500 mb-2">Session default channel group</label>
                    <div className="relative">
                        <select className="w-full appearance-none bg-white border border-slate-200 rounded-md px-3 py-2 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500/20">
                            <option>All</option>
                        </select>
                        <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                    </div>
                </div>

                <div>
                    <label className="block text-xs font-bold text-slate-500 mb-3 uppercase tracking-wider">Device category</label>
                    <div className="space-y-2">
                        {['(Blank)', 'desktop', 'mobile', 'smart tv', 'tablet'].map(cat => (
                            <label key={cat} className="flex items-center gap-3 cursor-pointer group">
                                <input type="checkbox" className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500" />
                                <span className="text-sm text-slate-600 group-hover:text-slate-900 transition-colors">{cat}</span>
                            </label>
                        ))}
                    </div>
                </div>

                <div>
                    <label className="block text-xs font-bold text-slate-500 mb-3 uppercase tracking-wider">Age Group Filter</label>
                    <div className="space-y-2">
                        {ageGroups.map(group => (
                            <label key={group} className="flex items-center gap-3 cursor-pointer group">
                                <input 
                                    type="checkbox" 
                                    checked={selectedAgeGroups.includes(group)}
                                    onChange={() => toggleAgeGroup(group)}
                                    className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500" 
                                />
                                <span className="text-sm text-slate-600 group-hover:text-slate-900 transition-colors">{group}</span>
                            </label>
                        ))}
                    </div>
                </div>
            </div>
          </div>

          {/* Help Section */}
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <div className="flex items-center justify-between mb-4">
                <h4 className="text-sm font-bold text-slate-900">Have questions?</h4>
                <div className="relative">
                    <img src="https://picsum.photos/seed/user/100/100" alt="Support" className="w-10 h-10 rounded-full border-2 border-white shadow-sm" />
                    <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 border-2 border-white rounded-full" />
                </div>
            </div>
            <div className="space-y-3">
                <a href="#" className="flex items-center gap-2 text-xs font-bold text-blue-600 hover:underline">
                    Dashboard setup guide
                </a>
                <a href="#" className="flex items-center gap-2 text-xs font-bold text-blue-600 hover:underline">
                    Book a demo
                </a>
                <div className="flex items-center gap-3 pt-2">
                    <a href="#" className="text-xs font-bold text-blue-600 hover:underline">Contact support</a>
                    <div className="flex items-center gap-2 ml-auto">
                        <Youtube className="w-4 h-4 text-red-600" />
                        <Globe className="w-4 h-4 text-blue-500" />
                    </div>
                </div>
            </div>
          </div>

          {/* Data Actions */}
          <div className="flex flex-col gap-2">
            <label className="flex items-center justify-center gap-2 bg-white border border-slate-200 rounded-lg px-4 py-2.5 cursor-pointer hover:bg-slate-50 transition-colors shadow-sm">
              <Upload className="w-4 h-4 text-slate-600" />
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">Upload CSV</span>
              <input type="file" accept=".csv" className="hidden" onChange={handleFileUpload} />
            </label>
            <button className="flex items-center justify-center gap-2 bg-slate-900 text-white rounded-lg px-4 py-2.5 hover:bg-slate-800 transition-colors shadow-sm">
              <Download className="w-4 h-4" />
              <span className="text-xs font-bold uppercase tracking-wider">Export PDF</span>
            </button>
          </div>
        </aside>
      </div>

      {/* Footer Branding */}
      <footer className="bg-[#4c1d95] text-white text-center py-2 text-xs font-bold">
        Connect 70+ data sources with Coupler.io
      </footer>
    </div>
  );
}

function KPICard({ title, value, color, subValue, label }: { title: string, value: string, color: string, subValue: string, label: string }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn("p-5 rounded-xl text-white shadow-md", color)}
    >
      <p className="text-xs font-medium opacity-80 mb-2">{label}</p>
      <h4 className="text-2xl font-bold">{subValue}</h4>
    </motion.div>
  );
}

function ChartContainer({ title, children, className }: { title: string, children: React.ReactNode, className?: string }) {
  return (
    <div className={cn("bg-white p-5 rounded-xl shadow-sm border border-slate-200", className)}>
      <h3 className="text-sm font-bold text-slate-900 mb-4">{title}</h3>
      {children}
    </div>
  );
}

